# puffer-firetv-example
Stanford Puffer Live TV Streaming App for Fire TV (Example / How-to)

## Full Guide / Tutorial

https://medium.com/p/if-youve-never-considered-building-a-fire-tv-app-before-do-it-it-s-stupid-how-easy-it-is-c19fd3f675af

## Editing the gh-pages branch (not this one)

**THIS IS NOT THE GH-PAGES BRANCH! EDIT THE [GH-PAGES BRANCH](../../tree/gh-pages) INSTEAD OF THIS ONE!**

If you're forking this repository, you'll want to edit the `gh-pages` branch and replace the session details at the bottom of `index.html` with your own.

You can watch this video to see exactly how it's done: 
https://www.loom.com/share/24f6ecd0c9484e2fb6878d4bd8a6c8db

## Publishing

Once you publish your `gh-pages` branch, your final url will be something like this:

https://kidgodzilla.github.io/puffer-firetv-example/

(with the username being your own).
